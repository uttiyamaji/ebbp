

def ebb_fit_estimate():
    pass