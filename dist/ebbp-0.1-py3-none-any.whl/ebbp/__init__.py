

""" adding __init__() for making a directory"""


from ebbp.src.ebb_fit_prior import ebb_fit_prior, augment
from ebbp.src.add_ebb_estimate import add_ebb_estimate



# #ebb_fit_prior()



#import ebb_fit_prior
#import add_ebb_estimate